# Uofthacks12 > 2025-01-18 6:42pm
https://universe.roboflow.com/donttaptest/uofthacks12

Provided by a Roboflow user
License: CC BY 4.0

